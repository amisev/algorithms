import java.util.Iterator;
// import java.lang.IllegalArgumentException;
import java.util.NoSuchElementException;
// import java.lang.UnsupportedOperationException;

public class Deque<Item> implements Iterable<Item> {

    private class Node {
        Item item;
        Node next;
    }

    private Node first;
    private Node last;
    private int size = 0;

    public Deque() {
        first = last = null;
    }

    public boolean isEmpty() {
        return size == 0;
     }

    public int size(){
        return size;
    }
    public void addFirst(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }

        Node newFirst = new Node();
        newFirst.item = item;
        newFirst.next = first;
        first = newFirst;

        if (last == null) last = first;
        size++;
    }
    public void addLast(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }

        Node newLast = new Node();
        newLast.item = item;
        newLast.next = null;
        last.next = newLast;
        last = newLast;

        if (first == null) first = last;
        size++;
    }
    public Item removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        } 
        size--;

        Item item = first.item;
        first = first.next;
        return item;
    }
    public Item removeLast() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        } 
        size--;

        Item item = last.item;
        Node node = first;
        while (node.next.next != null) {
            node = node.next;
        }
        last = node;
        last.next = null;

        return item;
    }
    public Iterator<Item> iterator() {
        return new DequeIterator();
    }

    private class DequeIterator implements Iterator<Item> {
        private Node current = first;
        public boolean hasNext() { return current != last.next; }
        public void remove() { throw new UnsupportedOperationException(); }
        public Item next() {
            Item item = current.item;
            current = current.next;
            return item;
        }
    }

    public static void main(String[] args) {
        Deque<String> deck = new Deque<>();

        deck.addFirst("item1");
        deck.addFirst("item2");
        deck.addFirst("item3");
        deck.addLast("item4");

        for (String n: deck)
            System.out.println(n);

        /*
        System.out.println(deck.first.item);
        System.out.println(deck.last.item);


        String item1 = deck.removeLast();
        System.out.println(item1);

        String item11 = deck.removeLast();
        System.out.println(item11);
        
        String item2 = deck.removeFirst();
        System.out.println(item2);
        */
    }
}
