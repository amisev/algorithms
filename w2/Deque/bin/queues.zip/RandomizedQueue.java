import java.util.Iterator;
// import java.lang.IllegalArgumentException;
import java.util.NoSuchElementException;
// import java.lang.UnsupportedOperationException;

import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {

    private class Node {
        Item item;
        Node next;
    }

    private Node first, last;
    private int size = 0;

    public RandomizedQueue() {

    }
    public boolean isEmpty() {
        return size == 0;
    }
    public int size() {
        return size;
    }
    public void enqueue(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }

        Node newNode = new Node();
        newNode.item = item;
        newNode.next = null;

        if (isEmpty()) {
            first = last = newNode; 
        } else {
            last.next = newNode;
            last = newNode;
        }

        size++;
    }
    public Item dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        } 
        size--;
        int i = StdRandom.uniform(size()); 
        int j = 0;
        Node current = first;
        while (j++ < i){
            current = current.next;
        }
        Item item = current.item;
        current.next = null;
        current.next = current.next.next;
        return item;
    }
    public Item sample() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        } 
        int i = StdRandom.uniform(size()); 
        int j = 0;

        Node current = first;
        while (j++ < i) {
            current = current.next;
        }
        Item item = current.item;
        return item;
    }
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }
    private class RandomizedQueueIterator implements Iterator<Item> {
        private Node current = first;
        public boolean hasNext() { return current != last.next; }
        public void remove() { throw new UnsupportedOperationException(); }
        public Item next() {
            Item item = current.item;
            current = current.next;
            return item;
        }
    }
    public static void main(String[] args) {

        RandomizedQueue<String> rq = new RandomizedQueue<>();
        rq.enqueue("item1");
        rq.enqueue("item2");
        rq.enqueue("item3");
        rq.enqueue("item4");

        String item = rq.sample();
        System.out.println(item);

        for (String n: rq) 
            System.out.println(n);
    }
}
