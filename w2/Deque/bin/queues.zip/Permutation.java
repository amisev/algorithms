import edu.princeton.cs.algs4.StdIn;
// import RandomizedQueue;

public class Permutation {
    public static void main(String[] args) {
        RandomizedQueue<String> rq = new RandomizedQueue<>();
        int k = StdIn.readInt();
        for (int i=0; i<k; i++) {
            String line = StdIn.readString();
            rq.enqueue(line);
        }
        for (int i=0; i<k; i++) {
           System.out.println(rq.dequeue());
        }
    }
}
