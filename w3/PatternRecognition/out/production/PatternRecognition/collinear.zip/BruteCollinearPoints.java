import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {

    private ArrayList<LineSegment> segments;
    /**
     *
     * @param points
     */
    public BruteCollinearPoints(Point[] points) {
        if (points == null) throw new NullPointerException();
        for (Point point: points) if (point == null) throw new NullPointerException();

        Point[] aux = Arrays.copyOf(points, points.length);
        // check for duplicate points
        for (int i = 1; i < aux.length; i++) {
            if (aux[i].compareTo(aux[i-1]) == 0) throw new IllegalArgumentException();
        }
        Arrays.sort(aux);

        this.segments = new ArrayList<> ();
        // n^4 complexity
        for (int p = 0; p < aux.length; p++) {
            for (int q = p + 1; q < aux.length; q++) {
                for (int r = q + 1; r < aux.length; r++) {
                    for (int s = r + 1; s < aux.length; s++) {
                        if (aux[p].slopeTo(aux[q]) == aux[p].slopeTo(aux[r]) &&  aux[p].slopeTo(aux[r]) == aux[p].slopeTo(aux[s])) {
                            LineSegment segment = new LineSegment(aux[p], aux[s]);
                            segments.add(segment);
                        }
                    }
                }
            }
        }
    }

    /**
     *
     * @return
     */
    public int numberOfSegments(){
        return segments.size();
    }

    /**
     *
     * @return
     */
    public LineSegment[] segments() {
        return segments.toArray(new LineSegment[0]);
    }

    public static  void main(String[] args) {
        Point[] points = new Point[6];
        points[0] = new Point(1, 1);
        points[1] = new Point(1, 2);
        points[2] = new Point(2, 2);
        points[3] = new Point(3, 3);
        points[4] = new Point(5, 5);
        points[5] = new Point(2, 1);

        BruteCollinearPoints bcp = new BruteCollinearPoints(points);
        System.out.println("done!");
        System.out.println(bcp.numberOfSegments());
    }
}
